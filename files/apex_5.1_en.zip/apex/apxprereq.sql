Rem  Copyright (c) Oracle Corporation 2012. All Rights Reserved.
Rem
Rem    NAME
Rem      apxprereq.sql
Rem
Rem    DESCRIPTION
Rem      This script checks prerequisites for Application Express full development
Rem      environment installation and runtime only installation. It should not be
Rem      invoked directly.
Rem
Rem    NOTES
Rem      Assumes the SYS user is connected.
Rem
Rem    REQUIREMENTS
Rem      - Oracle Database 10.2.0.3 or later
Rem
Rem    Arguments:
Rem     Position 1: Installation type (MANUAL, RUNTIME, etc)
Rem     Position 2: Name of Application Express schema
Rem     Position 3: Name of tablespace for Application Express application user
Rem     Position 4: Name of tablespace for Application Express files user
Rem     Position 5: Name of temporary tablespace or tablespace group
Rem     Position 6: Phases
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem      vuvarov   06/26/2012 - Created
Rem      vuvarov   07/13/2012 - Exclude existing installation and tablespace checks for apxdvins.sql
Rem      jkallman  08/01/2012 - Set NLS_LENGTH_SEMANTICS = BYTE if 10.2XE
Rem      jkallman  08/16/2012 - Reverted NLS_LENGTH_SEMANTICS = BYTE modifications
Rem      jstraub   09/03/2013 - Changed version already installed check to use sys.dba_registry (bug 16205047)
Rem      cneumuel  11/29/2016 - Added phases parameter



set define '^'
set concat on
set concat .
set verify off
set termout off
set termout on

define INSTALL_TYPE = '^1'
define APPUN        = '^2'
define DATTS        = '^3'
define FFTS         = '^4'
define TEMPTS       = '^5'
define PHASES       = '^6'

whenever sqlerror exit
set serveroutput on


prompt ... Checking prerequisites (^INSTALL_TYPE)
prompt .

Rem  Check SYSDBA Privilege
begin
    for c1 in (
        select null
          from sys.dual
         where not exists (select null
                             from sys.session_privs
                            where privilege = 'SYSDBA')
    ) loop
        sys.dbms_output.put_line('Error: Application Express installation requires a connection with the SYSDBA privilege.');
        execute immediate 'bogus statement to force exit';
    end loop;
end;
/

Rem  Check for proper DB version
declare
    l_version number;
    l_edition varchar2(30) := 'notXE';
begin
    execute immediate
        'select to_number(replace(version, ''.'', null)) from sys.registry$ where cid = ''CATPROC'''
        into l_version;

    if l_version = 102010 then
        begin
            execute immediate
                'select edition from sys.registry$ WHERE cid = ''CATPROC'''
                into l_edition;
        exception
            when others then
                null;
        end;
    end if;

    if l_version < 102030 and l_edition != 'XE' then
        dbms_output.put_line('Error: Application Express installation requires database version 10.2.0.3 or later, or XE.');
        execute immediate 'bogus statement to force exit';
    end if;
end;
/

Rem  Check if this Application Express version is already installed (except when converting between Full Dev and Runtime)
declare
    c_install_type constant varchar2(30) := '^INSTALL_TYPE.';
begin
    if c_install_type not in ('ADD_DEV') then
        for c1 in (
            select null from sys.dba_registry where comp_id = 'APEX' and schema = upper('^APPUN')
        ) loop
            dbms_output.put_line('Error: This version of Application Express is already installed (^APPUN).');
            execute immediate 'bogus statement to force exit';
        end loop;
    end if;
end;
/

Rem  Check for PL/SQL Web Toolkit
declare
    l_xx varchar2(1000);
begin
    execute immediate
        'begin :a := sys.owa_util.get_version(); end;'
        using out l_xx;
exception
    when others then
        dbms_output.put_line('Error: Application Express installation requires the PL/SQL Web Toolkit.');
        raise;
end;
/

Rem  Check for XDB
begin
    for c1 in (
        select null
          from sys.dual
         where not exists (select null
                             from sys.dba_registry
                            where comp_id = 'XDB'
                              and status = 'VALID')
    ) loop
        dbms_output.put_line('Error: Application Express installation requires the Oracle XML Database database component.');
        execute immediate 'bogus statement to force exit';
    end loop;
end;
/

Rem  Check that tablespaces passed in exist (except when converting between Full Dev and Runtime)
declare
    c_install_type constant varchar2(30) := '^INSTALL_TYPE.';

    procedure check_tbs(
        p_tablespace  in varchar2,
        p_check_group in varchar2 default 'N')
    is
    begin
        for c1 in (
            select null
              from sys.dual
             where not exists (select null
                                 from sys.dba_tablespaces
                                where tablespace_name = upper(p_tablespace)
                                union all
                               select null
                                 from sys.dba_tablespace_groups
                                where group_name = upper(p_tablespace)
                                  and p_check_group = 'Y')
        ) loop
            dbms_output.put_line('Error: The tablespace ' || p_tablespace || ' does not exist.');
            execute immediate 'bogus statement to force exit';
        end loop;
    end check_tbs;
begin
    if c_install_type not in ('ADD_DEV') then
        check_tbs('^DATTS');
        check_tbs('^FFTS');
        check_tbs('^TEMPTS', 'Y');
    end if;
end;
/

Rem Check PHASES parameter
declare
    l_count number;
    e_table_does_not_exist exception;
    pragma exception_init(e_table_does_not_exist, -942);
--------------------------------------------------------------------------------
    function has_apex_schema return boolean
    is
    begin
        select count(*)
          into l_count
          from sys.dba_users
         where username = '^APPUN';
        return l_count > 0;
    end has_apex_schema;
--------------------------------------------------------------------------------
    function has_flows return boolean
    is
    begin
        begin
            execute immediate 'select count(*) from ^APPUN..wwv_flows'
               into l_count;
        exception when e_table_does_not_exist then l_count := 0;
        end;
        return l_count > 0;
    end has_flows;
--------------------------------------------------------------------------------
    function has_registry return boolean
    is
    begin
        select count(*)
          into l_count
          from sys.dba_registry
         where comp_id = 'APEX'
           and schema  = '^APPUN';
        return l_count > 0;
    end has_registry;
--------------------------------------------------------------------------------
begin
    --
    -- preconditions:
    -- - PHASES must be 1 2 3 1,2 2,3 or 1,2,3
    -- - Phase 1: APEX_nnnnnn must not exist
    -- - Phase 2, Phase 3: APEX_nnnnnn must exist
    -- - Phase 2: wwv_flows must be empty
    -- - Phase 3: wwv_flows must not be empty
    -- - Phase 3: dba_registry must not point to APEX_nnnnnn
    -- - PHASES not 1,2,3: not supported in CDB$ROOT
    --
    if nvl(length('^PHASES'),0) = 0 or not regexp_like('^PHASES','^'||'(1|2|3|1,2,3|1,2|2,3)$') then
        raise_application_error (
            -20001,
            'Invalid value for phases: "^PHASES". Should be 1 2 3 1,2,3 1,2 or 2,3' );
    elsif instr('^PHASES','1') > 0 then
        if has_apex_schema then
            raise_application_error (
                -20001,
                'Precondition for Phase 1 failed: ^APPUN already exists' );
        end if;
    else
        if regexp_instr('^PHASES','[23]') > 0 and not has_apex_schema then
            raise_application_error (
                -20001,
                'Precondition for Phase 2,3 failed: ^APPUN does not exist' );
        end if;

        if instr('^PHASES',2) > 0 then
            if has_flows then
                raise_application_error (
                    -20001,
                    'Precondition for Phase 2 failed: Applications already installed' );
            end if;
        elsif instr('^PHASES','3') > 0 then
            if not has_flows then
                raise_application_error (
                    -20001,
                    'Precondition for Phase 3 failed: Applications not installed' );
            end if;
            if has_registry then
                raise_application_error (
                    -20001,
                    'Precondition for Phase 3 failed: Already switched to schema ^APPUN' );
            end if;
        end if;
    end if;
    --
    if '^PHASES' <> '1,2,3' and sys.dbms_db_version.version >= 12 then
        begin
            execute immediate q'{select count(*) from sys.dual where sys_context('userenv','con_name')='CDB$ROOT' }'
               into l_count;
        exception when others then l_count := null;
        end;
        if l_count > 0 then
            raise_application_error (
                -20001,
                'Reduced downtime upgrade is not supported for installation in CDB$ROOT' );
        end if;
    end if;
end;
/

prompt .
prompt ... Prerequisite checks passed.
prompt .

whenever sqlerror continue
