set define '^' verify off
prompt ...wwv_flow_session_api.sql
create or replace package wwv_flow_session_api authid current_user as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2016. All Rights Reserved.
--
--    NAME
--      wwv_flow_session_api.sql ( APEX_SESSION )
--
--    DESCRIPTION
--      This package enables you to configure Application Express sessions.
--
--    RUNTIME DEPLOYMENT: YES
--    PUBLIC:             YES
--
--    MODIFIED   (MM/DD/YYYY)
--    cneumuel    01/26/2016 - Created
--
--------------------------------------------------------------------------------

--==============================================================================
-- Set debug level for all future requests in a session.
--
-- ARGUMENTS
-- * p_session_id: The session id. The session must belong to the current
--                 workspace or the caller must be able to set the session's
--                 workspace.
-- * p_level:      The debug level. 0 or NULL disables debug, 1-9 sets a debug level.
--
-- EXAMPLE
--   Set debug for session 1234 to INFO level.
--
--   apex_session.set_debug (
--       p_session_id => 1234,
--       p_level      => apex_debug.c_log_level_info );
--   commit;
--
-- EXAMPLE
--   Disable debug in session 1234.
--
--   apex_session.set_debug (
--       p_session_id => 1234,
--       p_level      => null );
--   commit;
--
-- SEE ALSO
--   apex_debug.enable, apex_debug.disable
--==============================================================================
procedure set_debug (
    p_session_id in number default wwv_flow.g_instance,
    p_level      in wwv_flow_debug_api.t_log_level );

--==============================================================================
-- Set trace mode in all future requests of a session.
--
-- ARGUMENTS
-- * p_session_id: The session id. The session must belong to the current
--                 workspace or the caller must be able to set the session's
--                 workspace.
-- * p_trace:      The trace mode. NULL disables trace, SQL enables SQL trace.
--
-- EXAMPLE
--   Enable trace in requests for session 1234.
--
--   apex_session.set_trace (
--       p_session_id => 1234,
--       p_mode       => 'SQL' );
--   commit;
--
-- EXAMPLE
--   Disable trace in requests for session 1234.
--
--   apex_session.set_trace (
--       p_session_id => 1234,
--       p_mode       => null );
--   commit;
--==============================================================================
procedure set_trace (
    p_session_id in number default wwv_flow.g_instance,
    p_mode       in varchar2 );

end wwv_flow_session_api;
/
show err

