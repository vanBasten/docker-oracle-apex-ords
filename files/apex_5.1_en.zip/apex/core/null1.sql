set define '^' verify off
prompt ...null1.sql

Rem  Copyright (c) Oracle Corporation 2001. All Rights Reserved.
Rem
Rem    NAME
Rem      trigger.sql
Rem
Rem    DESCRIPTION
Rem      This file does absolutely nothing.  It is simply a file that can be run when different scripts are conditionally run
Rem      and the desired effect of a condition is for nothing to happen.
Rem
Rem    NOTES
Rem
Rem    ARGUMENTS
Rem
Rem    RUNTIME DEPLOYMENT: YES
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem       tmuth  10/08/2001 - Created
