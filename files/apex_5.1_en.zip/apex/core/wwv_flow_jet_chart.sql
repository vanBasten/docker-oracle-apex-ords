set define '^' verify off
prompt ...wwv_flow_jet_chart
create or replace package wwv_flow_jet_chart
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2016. All Rights Reserved.
--
--    NAME
--      wwv_flow_jet_chart.sql
--
--    DESCRIPTION
--      This package is responsible for handling JET chart rendering.
--
--    MODIFIED      (MM/DD/YYYY)
--    hfarrell       08/28/2015 - Created
--    hfarrell       10/01/2015 - Applied changes following review by Patrick
--    hfarrell       11/11/2015 - Added legend_title to t_chart_info; updated some t_chart_info params to boolean
--    hfarrell       11/20/2015 - Added group_col_data_type (may use for group sorting)
--    hfarrell       11/25/2015 - Added range_chart to t_chart_info
--    hfarrell       12/11/2015 - Added pie_inner_radius to t_chart_info; added pie_slice_explode to t_series
--    hfarrell       01/11/2016 - Added custom to t_data_point; added custom_column_name to t_series; added stock_render_as, pie_selection_effect, automatic_refresh_interval to t_chart_info
--    hfarrell       02/03/2016 - Added color to t_data_point, for colouring of data points
--    hfarrell       02/08/2016 - Added min_value to t_data_point for dial gauge chart
--    hfarrell       02/11/2016 - Updated t_chart_info: value_text_type, removed value_prefix, value_postfix
--    hfarrell       02/12/2016 - Updated t_axis: added format_scaling
--    hfarrell       04/01/2016 - Updated t_data_point.x: increased data type size to handle large numeric values NOTE: can also be a date, so handled as varchar to cater for both
--    hfarrell       04/06/2016 - Renamed t_data_point.group_name to series_short_desc - repurposed to be used for legend tooltip setting
--    hfarrell       04/20/2016 - Added zoom_direction to t_chart_info
--    hfarrell       05/20/2016 - Added no_data_found_message to t_chart_info
--    hfarrell       06/23/2016 - Added initial_zooming to t_chart_info

--==============================================================================
-- Definition of chart data, axis, series and chart info record types
--==============================================================================
-- Data Record
type t_data_point is record (
    id                            number,
    series_name                   varchar2(255),
    value                         number, 
    low                           number,  
    high                          number,
    open                          number, 
    close                         number,
    volume                        number,
    x                             varchar2(255),  --number/Date
    y                             number,
    z                             number,
    target_value                  number,
    min_value                     number,
    max_value                     number,
    series_short_desc             varchar2(4000),
    group_col_data_type           varchar2(100),
    group_short_desc              varchar2(4000),  
    label                         varchar2(255),
    item_short_desc               varchar2(4000),
    link_target                   varchar2(4000),
    custom                        varchar2(4000),
    color                         varchar2(128)
);

type t_data_points is table of t_data_point index by pls_integer;

-- Axis Record
type t_axis is record (
    static_id                     wwv_flow_jet_chart_axes.static_id%type,
    axis                          wwv_flow_jet_chart_axes.axis%type,
    is_rendered                   wwv_flow_jet_chart_axes.is_rendered%type,
    title                         wwv_flow_jet_chart_axes.title%type,
    min                           wwv_flow_jet_chart_axes.min%type,
    max                           wwv_flow_jet_chart_axes.max%type,
    format_type                   wwv_flow_jet_chart_axes.format_type%type,
    decimal_places                wwv_flow_jet_chart_axes.decimal_places%type,
    currency                      wwv_flow_jet_chart_axes.currency%type,
    numeric_pattern               wwv_flow_jet_chart_axes.numeric_pattern%type,
    format_scaling                wwv_flow_jet_chart_axes.format_scaling%type,
    scaling                       wwv_flow_jet_chart_axes.scaling%type,
    baseline_scaling              wwv_flow_jet_chart_axes.baseline_scaling%type,
    step                          wwv_flow_jet_chart_axes.step%type,
    position                      wwv_flow_jet_chart_axes.position%type,
    major_tick_rendered           wwv_flow_jet_chart_axes.major_tick_rendered%type,
    min_step                      wwv_flow_jet_chart_axes.min_step%type,
    minor_tick_rendered           wwv_flow_jet_chart_axes.minor_tick_rendered%type,
    minor_step                    wwv_flow_jet_chart_axes.minor_step%type,
    tick_label_rendered           wwv_flow_jet_chart_axes.tick_label_rendered%type,
    tick_label_rotation           wwv_flow_jet_chart_axes.tick_label_rotation%type,
    tick_label_position           wwv_flow_jet_chart_axes.tick_label_position%type,
    split_dual_y                  wwv_flow_jet_chart_axes.split_dual_y%type, 
    splitter_position             wwv_flow_jet_chart_axes.splitter_position%type);
    
type t_axes is table of t_axis index by pls_integer;

-- Series Record - to hold series attributes and associated data
type t_series is record (
    id                            wwv_flow_jet_chart_series.id%type,
    chart_id                      wwv_flow_jet_chart_series.chart_id%type,
    static_id                     wwv_flow_jet_chart_series.static_id%type,
    flow_id                       wwv_flow_jet_chart_series.flow_id%type,
    page_id                       wwv_flow_jet_chart_series.page_id%type,
    seq                           wwv_flow_jet_chart_series.seq%type,
    name                          wwv_flow_jet_chart_series.name%type,
    data_source_type              wwv_flow_jet_chart_series.data_source_type%type,
    data_source                   varchar2(32767),  -- For result caching, handle the CLOB column as VARCHAr2(32767)
    --
    series_data                   t_data_points,
    --
    max_row_count                 wwv_flow_jet_chart_series.max_row_count%type,
    ajax_items_to_submit          wwv_flow_jet_chart_series.ajax_items_to_submit%type,
    series_type                   wwv_flow_jet_chart_series.series_type%type,
    chart_type                    wwv_flow_jet_charts.chart_type%type,
    series_name_column_name       wwv_flow_jet_chart_series.series_name_column_name%type,
    items_value_column_name       wwv_flow_jet_chart_series.items_value_column_name%type,
    items_label_column_name       wwv_flow_jet_chart_series.items_label_column_name%type,
    items_short_desc_column_name  wwv_flow_jet_chart_series.items_short_desc_column_name%type,
    items_low_column_name         wwv_flow_jet_chart_series.items_low_column_name%type,
    items_high_column_name        wwv_flow_jet_chart_series.items_high_column_name%type,
    items_open_column_name        wwv_flow_jet_chart_series.items_open_column_name%type,
    items_close_column_name       wwv_flow_jet_chart_series.items_close_column_name%type,
    items_volume_column_name      wwv_flow_jet_chart_series.items_volume_column_name%type,
    items_x_column_name           wwv_flow_jet_chart_series.items_x_column_name%type,
    items_y_column_name           wwv_flow_jet_chart_series.items_y_column_name%type,
    items_z_column_name           wwv_flow_jet_chart_series.items_z_column_name%type,
    items_target_value            wwv_flow_jet_chart_series.items_target_value%type,
    items_min_value               wwv_flow_jet_chart_series.items_min_value%type,
    items_max_value               wwv_flow_jet_chart_series.items_max_value%type,
    group_name_column_name        wwv_flow_jet_chart_series.group_name_column_name%type,
    group_short_desc_column_name  wwv_flow_jet_chart_series.group_short_desc_column_name%type,
    custom_column_name            wwv_flow_jet_chart_series.custom_column_name%type,
    color                         wwv_flow_jet_chart_series.color%type,
    line_style                    wwv_flow_jet_chart_series.line_style%type,
    line_width                    wwv_flow_jet_chart_series.line_width%type,
    line_type                     wwv_flow_jet_chart_series.line_type%type,
    marker_rendered               wwv_flow_jet_chart_series.marker_rendered%type,
    marker_shape                  wwv_flow_jet_chart_series.marker_shape%type,
    assigned_to_y2                wwv_flow_jet_chart_series.assigned_to_y2%type, 
    --
    items_label_rendered          boolean,
    items_label_position          wwv_flow_jet_chart_series.items_label_position%type,
    items_label_css_classes       wwv_flow_jet_chart_series.items_label_css_classes%type,
    --
    link_target                   wwv_flow_jet_chart_series.link_target%type,
    link_target_type              wwv_flow_jet_chart_series.link_target_type%type
);

type t_chart_series_tbl is table of t_series index by pls_integer;

-- Chart Record - to hold chart attributes, axes and series information
type t_chart_info is record (
    id                            wwv_flow_jet_charts.id%type,
    flow_id                       wwv_flow_jet_charts.flow_id%type,
    page_id                       wwv_flow_jet_charts.page_id%type,
    region_id                     wwv_flow_jet_charts.region_id%type,
    chart_type                    wwv_flow_jet_charts.chart_type%type,
    --
    series                        t_chart_series_tbl,
    axes                          t_axes,
    --
    region_source                 varchar2(32767),
    region_items_to_submit        varchar2(32767),
    --
    title                         wwv_flow_jet_charts.title%type,
    width                         wwv_flow_jet_charts.width%type,
    height                        wwv_flow_jet_charts.height%type,
    animation_on_display          wwv_flow_jet_charts.animation_on_display%type,
    animation_on_data_change      wwv_flow_jet_charts.animation_on_data_change%type,
    orientation                   wwv_flow_jet_charts.orientation%type,
    data_cursor                   wwv_flow_jet_charts.data_cursor%type,
    data_cursor_behavior          wwv_flow_jet_charts.data_cursor_behavior%type,
    hide_and_show_behavior        wwv_flow_jet_charts.hide_and_show_behavior%type,
    hover_behavior                wwv_flow_jet_charts.hover_behavior%type,
    stack                         wwv_flow_jet_charts.stack%type,
    spark_chart                   boolean,
    stock_render_as               wwv_flow_jet_charts.stock_render_as%type,
    dial_indicator                wwv_flow_jet_charts.dial_indicator%type,
    dial_background               wwv_flow_jet_charts.dial_background%type,
    pie_selection_effect          wwv_flow_jet_charts.pie_selection_effect%type,
    value_min                     wwv_flow_jet_charts.value_min%type,
    value_text_type               wwv_flow_jet_charts.value_text_type%type,
    value_format_type             wwv_flow_jet_charts.value_format_type%type,
    value_decimal_places          wwv_flow_jet_charts.value_decimal_places%type,
    value_currency                wwv_flow_jet_charts.value_currency%type,
    value_numeric_pattern         wwv_flow_jet_charts.value_numeric_pattern%type,
    value_format_scaling          wwv_flow_jet_charts.value_format_scaling%type,
    zoom_and_scroll               wwv_flow_jet_charts.zoom_and_scroll%type,
    zoom_direction                wwv_flow_jet_charts.zoom_direction%type,
    initial_zooming               wwv_flow_jet_charts.initial_zooming%type,
    tooltip_rendered              wwv_flow_jet_charts.tooltip_rendered%type,
    show_series_name              boolean,
    show_group_name               boolean,
    show_value                    boolean,
    show_label                    boolean,
    custom_tooltip                wwv_flow_jet_charts.custom_tooltip%type,
    legend_rendered               wwv_flow_jet_charts.legend_rendered%type,
    legend_title                  wwv_flow_jet_charts.legend_title%type,
    legend_position               wwv_flow_jet_charts.legend_position%type,
    overview_rendered             wwv_flow_jet_charts.overview_rendered%type,
    overview_height               wwv_flow_jet_charts.overview_height%type,
    pie_other_threshold           wwv_flow_jet_charts.pie_other_threshold%type,
    time_axis_type                wwv_flow_jet_charts.time_axis_type%type,
    no_data_found_message         wwv_flow_jet_charts.no_data_found_message%type,
    javascript_code               wwv_flow_jet_charts.javascript_code%type,
    automatic_refresh_interval    wwv_flow_jet_charts.automatic_refresh_interval%type
);

--==============================================================================
-- Returns a chart record, with data, for the given region ID
-- NOTE: The data is added in t_chart_info.series(x).series_data
--==============================================================================    
function get_chart_data (
    p_chart_info         in t_chart_info,
    p_region             in wwv_flow_plugin_api.t_region)
    return t_chart_info;

/*procedure get_chart_json (
    p_page_id            in number,
    p_region_id          in number ); */
    --return clob;
    
--==============================================================================
-- Returns a varchar2 containing the chart attributes and data as a JSON object
-- for the given chart record
--==============================================================================
procedure emit_json (
    p_chart_info         in t_chart_info);

--==============================================================================
-- Renders the JET Chart based on the chart record type
--==============================================================================    
procedure render_jet_chart (
    p_region             in wwv_flow_plugin_api.t_region );

--==============================================================================
-- Returns the JET Chart data.
--==============================================================================
procedure ajax_jet_chart (
    p_region             in wwv_flow_plugin_api.t_region );

end wwv_flow_jet_chart;
/
show errors
